package com.example.jtest1;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class webViewActivity extends AppCompatActivity {

    WebView webView;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Context context;




    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.destroy();
    }


    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView = findViewById(R.id.webView);

        sharedPreferences = getSharedPreferences("pref_default", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        webView.setWebChromeClient(new WebChromeClient() {




            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(view.getContext())
                        .setTitle("app title")
                        .setMessage("app" + message)
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.d("[webView]", "확인버튼 클릭");
                                result.confirm();
                            }
                        })
                        .setCancelable(false)
                        .create().show();
                //return super.onJsAlert(view, url, message, result);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {



                Log.d("[webView]", "shouldOverriderurlLoading, url= " + request.getUrl());

                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {







                Log.d("[webView]", "onPageStarted , url = " + url);

                super.onPageStarted(view, url, favicon);


            }

            @Override
            public void onPageFinished(WebView view, String url) {

                Log.d("[webview]", "onPageFinished , url" + url);
                super.onPageFinished(view, url);
            }



        });
        WebSettings webSettigs = webView.getSettings();
        webSettigs.setJavaScriptEnabled(true);
        webSettigs.setLoadWithOverviewMode(true);

        webView.loadUrl("http://192.168.10.140:8080/public/test");
        webView.addJavascriptInterface(new JsInterface(this,webView), "android");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if(keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);

    }
}


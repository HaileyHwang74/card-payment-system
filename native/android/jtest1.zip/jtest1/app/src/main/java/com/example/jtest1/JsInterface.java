package com.example.jtest1;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

public class JsInterface {

    Context context;
    Activity activity;
    WebView webView;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;


String b;





    public  JsInterface(Context context, WebView webView){

        this.context = context;
        this.activity = (Activity) context;
        this.webView = webView;
        this.sharedPreferences = context.getSharedPreferences("pref_default", MODE_PRIVATE);
        this.editor = sharedPreferences.edit();
         b =  sharedPreferences.getString("text","hi");

    }

    @JavascriptInterface
    public void appFunction(String msg) {

        Toast.makeText(context, " in app=" +msg, Toast.LENGTH_SHORT).show();
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.loadUrl("javascript:jsFunction('app msg')");

            }
        });

    }


    @JavascriptInterface
    public void savetext(String a) {

        editor.putString("text" ,a );
        editor.apply();
    }


    @JavascriptInterface
    public void saveon() {

        editor.putBoolean("pushalarm" , true);
        editor.apply();

    }

    @JavascriptInterface
    public void saveoff(String msg) {
        boolean a =  sharedPreferences.getBoolean("pushalarm",false);

        editor.putBoolean("pushalarm" , false);
        editor.apply();

    }

    @JavascriptInterface
    public void startfunc(String msg) {
        boolean a =  sharedPreferences.getBoolean("pushalarm",true);
        String b =  sharedPreferences.getString("text","hi");
        if (a == true){
        Toast.makeText(context, b , Toast.LENGTH_SHORT).show();
        }
    }


    @JavascriptInterface
    public void gettext() {
        String b =  sharedPreferences.getString("text","hi");
            Toast.makeText(context, b , Toast.LENGTH_SHORT).show();

    }





}
